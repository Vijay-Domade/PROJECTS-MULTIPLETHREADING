package march21.org;
class good1 extends Thread
{
	public void run()
	{
		try
		{
			for(int i=1;i<=8;i++)
			{
				System.out.println("Good Morning");
				sleep(100);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error-->"+ex);
		}
		
	}
}
class welcome1 extends Thread
{
	public void run()
	{
		try
		{
			for(int i=1;i<=8;i++)
			{
				System.out.println("Welcome");
				sleep(300);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error-->"+ex);
		}
	}
}
public class delayGoodWelApp 
{

	public static void main(String[] args) 
	{
		good1 g=new good1();
		g.start();
		welcome1 w=new welcome1();
		w.start();

	}

}
