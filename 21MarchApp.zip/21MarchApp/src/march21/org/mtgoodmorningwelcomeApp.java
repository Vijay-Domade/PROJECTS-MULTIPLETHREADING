package march21.org;
class good extends Thread
{
	public void run()
	{
		try
		{
			for(int i=1;i<=10;i++)
			{
				System.out.println("Good Morning");
				sleep(1000);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error-->"+ex);
		}
		
	}
}
class welcome extends Thread
{
	public void run()
	{
		try
		{
			for(int i=1;i<=10;i++)
			{
				System.out.println("Welcome");
				sleep(1100);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error-->"+ex);
		}
	}
	
}
public class mtgoodmorningwelcomeApp 
{

	public static void main(String[] args)
	{
		good g=new good();
		g.start();
		welcome w=new welcome();
		w.start();

	}

}
