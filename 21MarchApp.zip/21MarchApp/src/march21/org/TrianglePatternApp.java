package march21.org;
class print extends Thread
{
	public void run()
	{
		try
		{
			for(int i=0;i<=4;i++)
			{
				System.out.printf("Triangle--->%d",(i+1));
				System.out.println(" ");
				sleep(1000);
			}
		}
		catch(Exception ex1)
		{
			System.out.println("Error--->"+ex1);

		}
	}
}
class triangle extends Thread
{
	public void run()
	{
		try
		{
	  for(int m=0;m<=4;m++)
	  {
			for(int i=0;i<=4;i++)
			{
				for(int j=0;j<=8;j++)
				{
					if( ( j==4-i ||  j==4+i  || i==4))
					{
						System.out.printf("*");
					}
					    System.out.printf("\t");
				}
				System.out.println(" ");
				
			  }
			System.out.println(" ");
			sleep(1100);
	     }
			
		 }
		catch(Exception ex)
		{
			System.out.println("Error--->"+ex);
		}
	}
}
public class TrianglePatternApp
{

	public static void main(String[] args)
	{
	 print p=new print();
	 p.start();
	 triangle tr=new triangle();
	 tr.start();
	}

}
