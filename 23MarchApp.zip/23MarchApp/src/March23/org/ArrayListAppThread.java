package March23.org;
import java.util.ArrayList;
import java.util.*;

class COP1
{
	ArrayList v=new ArrayList();
	void performOperation(int k)
	{
	  try
	  {
		 for(int i=1;i<=k;i++)
		 {
			 v.add(10*i);
			 Thread.sleep(1000);
		 }
	  }
	  catch(Exception ex)
	  {
		 System.out.println("Error is-->"+ex);
	  }
	}
}
class First1 extends Thread
{
	COP1 c;
	public void setCOP(COP1 c2)
	{
		this.c=c2;
	}
	public void run()
	{
		c.performOperation(5);
	}
	public void show()
	{
		for(Object obj:c.v)
		{
			System.out.println(obj);
		}
	}
}
class Second1 extends Thread
{
	COP1 c;
	int count=0;
	public void setCOP(COP1 c2)
	{
		this.c=c2;
	}
	public void run()
	{
		c.performOperation(5);
	}
	public void show()
	{
		for(Object obj:c.v)
		{
			System.out.println(obj);
		}
	}
}
public class ArrayListAppThread 
{

	public static void main(String[] args) 
	{
		COP1 c=new COP1();
		First1 f=new First1();
		f.setCOP(c);
		f.start();
		Second1 s=new Second1();
		s.setCOP(c);
		s.start();
		f.show();
		s.show();

	}

}
