package March23.org;
import java.util.*;
class Table3
{
	synchronized void showTable(int x)
	{
		try
		{
			for(int i=1;i<=10;i++)
			{
				System.out.printf("%d X %d =%d\n",i,x,i*x);
				if(i==5)
				{
					wait(50000);
				}
				Thread.sleep(1000);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error is"+ex);
		}
	}
}
class Two3 extends Thread
{
	Table3 t;
	void setTable(Table3 t1)
	{
		this.t=t1;
	}
	public void run()
	{
		t.showTable(2);
	}
}
class Three3 extends Thread
{
	Table3 t;
	void setTable(Table3 t1)
	{
		this.t=t1;
	}
	public void run()
	{
		t.showTable(3);
	}
}
public class UnconditionalWaitsApp
{

	public static void main(String[] args) 
	{
	  Table3 t1=new Table3();
	  Two3 tw=new Two3();
	  tw.setTable(t1);
	  tw.start();
	  Three3 th=new Three3();
	  th.setTable(t1);
	  th.start();

	}

}
