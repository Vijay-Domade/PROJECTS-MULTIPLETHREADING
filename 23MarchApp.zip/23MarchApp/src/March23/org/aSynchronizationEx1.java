package March23.org;
class Table
{
	void showTable(int x)
	{
	 try
	 {
		for(int i=1;i<=10;i++)
		{
			System.out.printf("%d X %d=%d\n",i,x,i*x);
		}
	 }
	 catch(Exception ex)
	 {
		 System.out.println("Error is-->"+ex);
	 }
	}
}
class Two extends Thread
{
	Table t;
	void setTable(Table t)
	{
		this.t=t;
	}
	public void run()
	{
		t.showTable(2);
	}
}
class Three extends Thread
{
	Table t;
	void setTable(Table t)
	{
		this.t=t;
	}
	public void run()
	{
		t.showTable(3);
	}
}
public class aSynchronizationEx1 
{

	public static void main(String[] args) 
	{
		Table t1=new Table();
		Two tw=new Two();
		tw.setTable(t1);
		tw.start();
		Three th=new Three();
		th.setTable(t1);
		th.start();

	}

}
