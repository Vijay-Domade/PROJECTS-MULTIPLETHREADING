package March23.org;
import java.util.*;

class COP
{
	Vector v=new Vector();
	void performOperation(int k)
	{
	  try
	  {
		 for(int i=1;i<=k;i++)
		 {
			 v.add(10*i);
			 Thread.sleep(1000);
		 }
	  }
	  catch(Exception ex)
	  {
		 System.out.println("Error is-->"+ex);
	  }
	}
}
class First extends Thread
{
	COP c;
	public void setCOP(COP c)
	{
		this.c=c;
	}
	public void run()
	{
		c.performOperation(5);
	}
	public void show()
	{
		for(Object obj:c.v)
		{
			System.out.println(obj);
		}
	}
}
class Second extends Thread
{
	COP c;
	int count=0;
	public void setCOP(COP c)
	{
		this.c=c;
	}
	public void run()
	{
		c.performOperation(5);
	}
	public void show()
	{
		for(Object obj:c.v)
		{
			System.out.println(obj);
		}
	}
}
public class VectorThreadApp
{

	public static void main(String[] args) 
	{
		COP c=new COP();
		First f=new First();
		f.setCOP(c);
		f.start();
		Second s=new Second();
		s.setCOP(c);
		s.start();
		f.show();
		s.show();

	}

}
