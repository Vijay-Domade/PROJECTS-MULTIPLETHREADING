package March23.org;
class Table1
{
	synchronized void showTable(int x)
	{
		try
		{
			for(int i=1;i<=10;i++)
			{
				System.out.printf("%d X %d=%d\n",i,x,i*x);
				Thread.sleep(1000);
			}
		}
		catch(Exception ex)
		{
			System.out.println("Error is"+ex);
		}
	}
}
class Two1 extends Thread
{
	Table1 t;
	void setTable(Table1 t1)
	{
		this.t=t1;
	}
	public void run()
	{
		t.showTable(2);
	}
}
class Three1 extends Thread
{
	Table1 t;
	void setTable(Table1 t1)
	{
		this.t=t1;
	}
	public void run()
	{
		t.showTable(3);
	}
}
public class SynchronizationApp 
{
	public static void main(String[] args) 
	{
		Table1 t1=new Table1();
		Two1 tw=new Two1();
		tw.setTable(t1);
		tw.start();
		Three1 th=new Three1();
		th.setTable(t1);
		th.start();

	}

}
